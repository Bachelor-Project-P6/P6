﻿Public Class Gate


    Private Sub BtnGate1_Click(sender As Object, e As EventArgs) Handles BtnGate1.Click
        Dim open As New MapResult
        open.ShowDialog()
        Close()
    End Sub

    Private Sub BtnGate2_Click(sender As Object, e As EventArgs) Handles BtnGate2.Click
        Dim open As New MapResult
        open.ShowDialog()
        Close()
    End Sub

    Private Sub BtnGate3_Click(sender As Object, e As EventArgs) Handles BtnGate3.Click
        Dim open As New MapResult
        open.ShowDialog()
        Close()
    End Sub

    Private Sub BtnGate4_Click(sender As Object, e As EventArgs) Handles BtnGate4.Click
        Dim open As New MapResult
        open.ShowDialog()
        Close()
    End Sub

    Private Sub BtnGate5_Click(sender As Object, e As EventArgs) Handles BtnGate5.Click
        Dim open As New MapResult
        open.ShowDialog()
        Close()
    End Sub

    Private Sub BtnGate6_Click(sender As Object, e As EventArgs) Handles BtnGate6.Click
        Dim open As New MapResult
        open.ShowDialog()
        Close()
    End Sub

    Private Sub BtnGate7_Click(sender As Object, e As EventArgs) Handles BtnGate7.Click
        Dim open As New MapResult
        open.ShowDialog()
        Close()
    End Sub

    Private Sub BtnGate8_Click(sender As Object, e As EventArgs) Handles BtnGate8.Click
        Dim open As New MapResult
        open.ShowDialog()
        Close()
    End Sub

    Private Sub BtnGate9_Click(sender As Object, e As EventArgs) Handles BtnGate9.Click
        Dim open As New MapResult
        open.ShowDialog()
        Close()
    End Sub

    Private Sub BtnGate10_Click(sender As Object, e As EventArgs) Handles BtnGate10.Click
        Dim open As New MapResult
        open.ShowDialog()
        Close()
    End Sub

    Private Sub BtnGate11_Click(sender As Object, e As EventArgs) Handles BtnGate11.Click
        Dim open As New MapResult
        open.ShowDialog()
        Close()
    End Sub

    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnBack.Click
        Close()
    End Sub
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Password
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.txtPasswordbox = New System.Windows.Forms.TextBox()
        Me.key1 = New System.Windows.Forms.Button()
        Me.key2 = New System.Windows.Forms.Button()
        Me.key3 = New System.Windows.Forms.Button()
        Me.key4 = New System.Windows.Forms.Button()
        Me.key5 = New System.Windows.Forms.Button()
        Me.key6 = New System.Windows.Forms.Button()
        Me.key7 = New System.Windows.Forms.Button()
        Me.key8 = New System.Windows.Forms.Button()
        Me.key9 = New System.Windows.Forms.Button()
        Me.key0 = New System.Windows.Forms.Button()
        Me.keyQ = New System.Windows.Forms.Button()
        Me.keyW = New System.Windows.Forms.Button()
        Me.keyE = New System.Windows.Forms.Button()
        Me.keyR = New System.Windows.Forms.Button()
        Me.keyT = New System.Windows.Forms.Button()
        Me.keyY = New System.Windows.Forms.Button()
        Me.keyU = New System.Windows.Forms.Button()
        Me.keyI = New System.Windows.Forms.Button()
        Me.keyO = New System.Windows.Forms.Button()
        Me.keyP = New System.Windows.Forms.Button()
        Me.keyA = New System.Windows.Forms.Button()
        Me.keyS = New System.Windows.Forms.Button()
        Me.keyD = New System.Windows.Forms.Button()
        Me.keyF = New System.Windows.Forms.Button()
        Me.keyG = New System.Windows.Forms.Button()
        Me.keyH = New System.Windows.Forms.Button()
        Me.keyJ = New System.Windows.Forms.Button()
        Me.keyK = New System.Windows.Forms.Button()
        Me.keyL = New System.Windows.Forms.Button()
        Me.keyZ = New System.Windows.Forms.Button()
        Me.keyX = New System.Windows.Forms.Button()
        Me.keyC = New System.Windows.Forms.Button()
        Me.keyV = New System.Windows.Forms.Button()
        Me.keyB = New System.Windows.Forms.Button()
        Me.keyN = New System.Windows.Forms.Button()
        Me.keyM = New System.Windows.Forms.Button()
        Me.btnEnterPassword = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.lblPassprompt = New System.Windows.Forms.Label()
        Me.keyBack = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'txtPasswordbox
        '
        Me.txtPasswordbox.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtPasswordbox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPasswordbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!)
        Me.txtPasswordbox.Location = New System.Drawing.Point(421, 244)
        Me.txtPasswordbox.Margin = New System.Windows.Forms.Padding(4)
        Me.txtPasswordbox.Name = "txtPasswordbox"
        Me.txtPasswordbox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPasswordbox.Size = New System.Drawing.Size(952, 45)
        Me.txtPasswordbox.TabIndex = 0
        '
        'key1
        '
        Me.key1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.key1.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.key1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.key1.Location = New System.Drawing.Point(333, 322)
        Me.key1.Margin = New System.Windows.Forms.Padding(4)
        Me.key1.Name = "key1"
        Me.key1.Size = New System.Drawing.Size(107, 70)
        Me.key1.TabIndex = 1
        Me.key1.Text = "1"
        Me.key1.UseVisualStyleBackColor = False
        '
        'key2
        '
        Me.key2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.key2.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.key2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.key2.Location = New System.Drawing.Point(448, 322)
        Me.key2.Margin = New System.Windows.Forms.Padding(4)
        Me.key2.Name = "key2"
        Me.key2.Size = New System.Drawing.Size(107, 70)
        Me.key2.TabIndex = 2
        Me.key2.Text = "2"
        Me.key2.UseVisualStyleBackColor = False
        '
        'key3
        '
        Me.key3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.key3.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.key3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.key3.Location = New System.Drawing.Point(563, 322)
        Me.key3.Margin = New System.Windows.Forms.Padding(4)
        Me.key3.Name = "key3"
        Me.key3.Size = New System.Drawing.Size(107, 70)
        Me.key3.TabIndex = 3
        Me.key3.Text = "3"
        Me.key3.UseVisualStyleBackColor = False
        '
        'key4
        '
        Me.key4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.key4.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.key4.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.key4.Location = New System.Drawing.Point(677, 322)
        Me.key4.Margin = New System.Windows.Forms.Padding(4)
        Me.key4.Name = "key4"
        Me.key4.Size = New System.Drawing.Size(107, 70)
        Me.key4.TabIndex = 4
        Me.key4.Text = "4"
        Me.key4.UseVisualStyleBackColor = False
        '
        'key5
        '
        Me.key5.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.key5.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.key5.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.key5.Location = New System.Drawing.Point(792, 322)
        Me.key5.Margin = New System.Windows.Forms.Padding(4)
        Me.key5.Name = "key5"
        Me.key5.Size = New System.Drawing.Size(107, 70)
        Me.key5.TabIndex = 5
        Me.key5.Text = "5"
        Me.key5.UseVisualStyleBackColor = False
        '
        'key6
        '
        Me.key6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.key6.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.key6.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.key6.Location = New System.Drawing.Point(907, 322)
        Me.key6.Margin = New System.Windows.Forms.Padding(4)
        Me.key6.Name = "key6"
        Me.key6.Size = New System.Drawing.Size(107, 70)
        Me.key6.TabIndex = 6
        Me.key6.Text = "6"
        Me.key6.UseVisualStyleBackColor = False
        '
        'key7
        '
        Me.key7.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.key7.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.key7.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.key7.Location = New System.Drawing.Point(1021, 322)
        Me.key7.Margin = New System.Windows.Forms.Padding(4)
        Me.key7.Name = "key7"
        Me.key7.Size = New System.Drawing.Size(107, 70)
        Me.key7.TabIndex = 7
        Me.key7.Text = "7"
        Me.key7.UseVisualStyleBackColor = False
        '
        'key8
        '
        Me.key8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.key8.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.key8.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.key8.Location = New System.Drawing.Point(1136, 322)
        Me.key8.Margin = New System.Windows.Forms.Padding(4)
        Me.key8.Name = "key8"
        Me.key8.Size = New System.Drawing.Size(107, 70)
        Me.key8.TabIndex = 8
        Me.key8.Text = "8"
        Me.key8.UseVisualStyleBackColor = False
        '
        'key9
        '
        Me.key9.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.key9.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.key9.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.key9.Location = New System.Drawing.Point(1251, 322)
        Me.key9.Margin = New System.Windows.Forms.Padding(4)
        Me.key9.Name = "key9"
        Me.key9.Size = New System.Drawing.Size(107, 70)
        Me.key9.TabIndex = 9
        Me.key9.Text = "9"
        Me.key9.UseVisualStyleBackColor = False
        '
        'key0
        '
        Me.key0.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.key0.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.key0.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.key0.Location = New System.Drawing.Point(1365, 322)
        Me.key0.Margin = New System.Windows.Forms.Padding(4)
        Me.key0.Name = "key0"
        Me.key0.Size = New System.Drawing.Size(107, 70)
        Me.key0.TabIndex = 10
        Me.key0.Text = "0"
        Me.key0.UseVisualStyleBackColor = False
        '
        'keyQ
        '
        Me.keyQ.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyQ.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyQ.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyQ.Location = New System.Drawing.Point(333, 400)
        Me.keyQ.Margin = New System.Windows.Forms.Padding(4)
        Me.keyQ.Name = "keyQ"
        Me.keyQ.Size = New System.Drawing.Size(107, 70)
        Me.keyQ.TabIndex = 11
        Me.keyQ.Text = "Q"
        Me.keyQ.UseVisualStyleBackColor = False
        '
        'keyW
        '
        Me.keyW.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyW.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyW.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyW.Location = New System.Drawing.Point(448, 400)
        Me.keyW.Margin = New System.Windows.Forms.Padding(4)
        Me.keyW.Name = "keyW"
        Me.keyW.Size = New System.Drawing.Size(107, 70)
        Me.keyW.TabIndex = 12
        Me.keyW.Text = "W"
        Me.keyW.UseVisualStyleBackColor = False
        '
        'keyE
        '
        Me.keyE.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyE.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyE.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyE.Location = New System.Drawing.Point(563, 400)
        Me.keyE.Margin = New System.Windows.Forms.Padding(4)
        Me.keyE.Name = "keyE"
        Me.keyE.Size = New System.Drawing.Size(107, 70)
        Me.keyE.TabIndex = 13
        Me.keyE.Text = "E"
        Me.keyE.UseVisualStyleBackColor = False
        '
        'keyR
        '
        Me.keyR.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyR.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyR.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyR.Location = New System.Drawing.Point(677, 400)
        Me.keyR.Margin = New System.Windows.Forms.Padding(4)
        Me.keyR.Name = "keyR"
        Me.keyR.Size = New System.Drawing.Size(107, 70)
        Me.keyR.TabIndex = 14
        Me.keyR.Text = "R"
        Me.keyR.UseVisualStyleBackColor = False
        '
        'keyT
        '
        Me.keyT.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyT.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyT.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyT.Location = New System.Drawing.Point(792, 400)
        Me.keyT.Margin = New System.Windows.Forms.Padding(4)
        Me.keyT.Name = "keyT"
        Me.keyT.Size = New System.Drawing.Size(107, 70)
        Me.keyT.TabIndex = 15
        Me.keyT.Text = "T"
        Me.keyT.UseVisualStyleBackColor = False
        '
        'keyY
        '
        Me.keyY.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyY.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyY.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyY.Location = New System.Drawing.Point(907, 400)
        Me.keyY.Margin = New System.Windows.Forms.Padding(4)
        Me.keyY.Name = "keyY"
        Me.keyY.Size = New System.Drawing.Size(107, 70)
        Me.keyY.TabIndex = 16
        Me.keyY.Text = "Y"
        Me.keyY.UseVisualStyleBackColor = False
        '
        'keyU
        '
        Me.keyU.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyU.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyU.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyU.Location = New System.Drawing.Point(1021, 400)
        Me.keyU.Margin = New System.Windows.Forms.Padding(4)
        Me.keyU.Name = "keyU"
        Me.keyU.Size = New System.Drawing.Size(107, 70)
        Me.keyU.TabIndex = 17
        Me.keyU.Text = "U"
        Me.keyU.UseVisualStyleBackColor = False
        '
        'keyI
        '
        Me.keyI.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyI.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyI.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyI.Location = New System.Drawing.Point(1136, 400)
        Me.keyI.Margin = New System.Windows.Forms.Padding(4)
        Me.keyI.Name = "keyI"
        Me.keyI.Size = New System.Drawing.Size(107, 70)
        Me.keyI.TabIndex = 18
        Me.keyI.Text = "I"
        Me.keyI.UseVisualStyleBackColor = False
        '
        'keyO
        '
        Me.keyO.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyO.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyO.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyO.Location = New System.Drawing.Point(1251, 400)
        Me.keyO.Margin = New System.Windows.Forms.Padding(4)
        Me.keyO.Name = "keyO"
        Me.keyO.Size = New System.Drawing.Size(107, 70)
        Me.keyO.TabIndex = 19
        Me.keyO.Text = "O"
        Me.keyO.UseVisualStyleBackColor = False
        '
        'keyP
        '
        Me.keyP.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyP.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyP.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyP.Location = New System.Drawing.Point(1365, 400)
        Me.keyP.Margin = New System.Windows.Forms.Padding(4)
        Me.keyP.Name = "keyP"
        Me.keyP.Size = New System.Drawing.Size(107, 70)
        Me.keyP.TabIndex = 20
        Me.keyP.Text = "P"
        Me.keyP.UseVisualStyleBackColor = False
        '
        'keyA
        '
        Me.keyA.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyA.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyA.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyA.Location = New System.Drawing.Point(391, 478)
        Me.keyA.Margin = New System.Windows.Forms.Padding(4)
        Me.keyA.Name = "keyA"
        Me.keyA.Size = New System.Drawing.Size(107, 70)
        Me.keyA.TabIndex = 21
        Me.keyA.Text = "A"
        Me.keyA.UseVisualStyleBackColor = False
        '
        'keyS
        '
        Me.keyS.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyS.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyS.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyS.Location = New System.Drawing.Point(505, 478)
        Me.keyS.Margin = New System.Windows.Forms.Padding(4)
        Me.keyS.Name = "keyS"
        Me.keyS.Size = New System.Drawing.Size(107, 70)
        Me.keyS.TabIndex = 22
        Me.keyS.Text = "S"
        Me.keyS.UseVisualStyleBackColor = False
        '
        'keyD
        '
        Me.keyD.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyD.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyD.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyD.Location = New System.Drawing.Point(620, 478)
        Me.keyD.Margin = New System.Windows.Forms.Padding(4)
        Me.keyD.Name = "keyD"
        Me.keyD.Size = New System.Drawing.Size(107, 70)
        Me.keyD.TabIndex = 23
        Me.keyD.Text = "D"
        Me.keyD.UseVisualStyleBackColor = False
        '
        'keyF
        '
        Me.keyF.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyF.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyF.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyF.Location = New System.Drawing.Point(735, 478)
        Me.keyF.Margin = New System.Windows.Forms.Padding(4)
        Me.keyF.Name = "keyF"
        Me.keyF.Size = New System.Drawing.Size(107, 70)
        Me.keyF.TabIndex = 24
        Me.keyF.Text = "F"
        Me.keyF.UseVisualStyleBackColor = False
        '
        'keyG
        '
        Me.keyG.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyG.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyG.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyG.Location = New System.Drawing.Point(849, 478)
        Me.keyG.Margin = New System.Windows.Forms.Padding(4)
        Me.keyG.Name = "keyG"
        Me.keyG.Size = New System.Drawing.Size(107, 70)
        Me.keyG.TabIndex = 25
        Me.keyG.Text = "G"
        Me.keyG.UseVisualStyleBackColor = False
        '
        'keyH
        '
        Me.keyH.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyH.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyH.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyH.Location = New System.Drawing.Point(964, 478)
        Me.keyH.Margin = New System.Windows.Forms.Padding(4)
        Me.keyH.Name = "keyH"
        Me.keyH.Size = New System.Drawing.Size(107, 70)
        Me.keyH.TabIndex = 26
        Me.keyH.Text = "H"
        Me.keyH.UseVisualStyleBackColor = False
        '
        'keyJ
        '
        Me.keyJ.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyJ.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyJ.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyJ.Location = New System.Drawing.Point(1079, 478)
        Me.keyJ.Margin = New System.Windows.Forms.Padding(4)
        Me.keyJ.Name = "keyJ"
        Me.keyJ.Size = New System.Drawing.Size(107, 70)
        Me.keyJ.TabIndex = 27
        Me.keyJ.Text = "J"
        Me.keyJ.UseVisualStyleBackColor = False
        '
        'keyK
        '
        Me.keyK.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyK.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyK.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyK.Location = New System.Drawing.Point(1193, 478)
        Me.keyK.Margin = New System.Windows.Forms.Padding(4)
        Me.keyK.Name = "keyK"
        Me.keyK.Size = New System.Drawing.Size(107, 70)
        Me.keyK.TabIndex = 28
        Me.keyK.Text = "K"
        Me.keyK.UseVisualStyleBackColor = False
        '
        'keyL
        '
        Me.keyL.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyL.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyL.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyL.Location = New System.Drawing.Point(1308, 478)
        Me.keyL.Margin = New System.Windows.Forms.Padding(4)
        Me.keyL.Name = "keyL"
        Me.keyL.Size = New System.Drawing.Size(107, 70)
        Me.keyL.TabIndex = 29
        Me.keyL.Text = "L"
        Me.keyL.UseVisualStyleBackColor = False
        '
        'keyZ
        '
        Me.keyZ.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyZ.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyZ.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyZ.Location = New System.Drawing.Point(505, 555)
        Me.keyZ.Margin = New System.Windows.Forms.Padding(4)
        Me.keyZ.Name = "keyZ"
        Me.keyZ.Size = New System.Drawing.Size(107, 70)
        Me.keyZ.TabIndex = 30
        Me.keyZ.Text = "Z"
        Me.keyZ.UseVisualStyleBackColor = False
        '
        'keyX
        '
        Me.keyX.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyX.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyX.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyX.Location = New System.Drawing.Point(620, 555)
        Me.keyX.Margin = New System.Windows.Forms.Padding(4)
        Me.keyX.Name = "keyX"
        Me.keyX.Size = New System.Drawing.Size(107, 70)
        Me.keyX.TabIndex = 31
        Me.keyX.Text = "X"
        Me.keyX.UseVisualStyleBackColor = False
        '
        'keyC
        '
        Me.keyC.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyC.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyC.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyC.Location = New System.Drawing.Point(735, 555)
        Me.keyC.Margin = New System.Windows.Forms.Padding(4)
        Me.keyC.Name = "keyC"
        Me.keyC.Size = New System.Drawing.Size(107, 70)
        Me.keyC.TabIndex = 32
        Me.keyC.Text = "C"
        Me.keyC.UseVisualStyleBackColor = False
        '
        'keyV
        '
        Me.keyV.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyV.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyV.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyV.Location = New System.Drawing.Point(849, 555)
        Me.keyV.Margin = New System.Windows.Forms.Padding(4)
        Me.keyV.Name = "keyV"
        Me.keyV.Size = New System.Drawing.Size(107, 70)
        Me.keyV.TabIndex = 33
        Me.keyV.Text = "V"
        Me.keyV.UseVisualStyleBackColor = False
        '
        'keyB
        '
        Me.keyB.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyB.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyB.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyB.Location = New System.Drawing.Point(964, 555)
        Me.keyB.Margin = New System.Windows.Forms.Padding(4)
        Me.keyB.Name = "keyB"
        Me.keyB.Size = New System.Drawing.Size(107, 70)
        Me.keyB.TabIndex = 34
        Me.keyB.Text = "B"
        Me.keyB.UseVisualStyleBackColor = False
        '
        'keyN
        '
        Me.keyN.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyN.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyN.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyN.Location = New System.Drawing.Point(1079, 555)
        Me.keyN.Margin = New System.Windows.Forms.Padding(4)
        Me.keyN.Name = "keyN"
        Me.keyN.Size = New System.Drawing.Size(107, 70)
        Me.keyN.TabIndex = 35
        Me.keyN.Text = "N"
        Me.keyN.UseVisualStyleBackColor = False
        '
        'keyM
        '
        Me.keyM.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyM.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.keyM.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyM.Location = New System.Drawing.Point(1193, 555)
        Me.keyM.Margin = New System.Windows.Forms.Padding(4)
        Me.keyM.Name = "keyM"
        Me.keyM.Size = New System.Drawing.Size(107, 70)
        Me.keyM.TabIndex = 36
        Me.keyM.Text = "M"
        Me.keyM.UseVisualStyleBackColor = False
        '
        'btnEnterPassword
        '
        Me.btnEnterPassword.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnEnterPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!)
        Me.btnEnterPassword.Location = New System.Drawing.Point(333, 695)
        Me.btnEnterPassword.Margin = New System.Windows.Forms.Padding(4)
        Me.btnEnterPassword.Name = "btnEnterPassword"
        Me.btnEnterPassword.Size = New System.Drawing.Size(443, 143)
        Me.btnEnterPassword.TabIndex = 37
        Me.btnEnterPassword.Text = "ENTER"
        Me.btnEnterPassword.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!)
        Me.btnCancel.Location = New System.Drawing.Point(1021, 695)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(443, 143)
        Me.btnCancel.TabIndex = 38
        Me.btnCancel.Text = "CANCEL"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'lblPassprompt
        '
        Me.lblPassprompt.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblPassprompt.AutoSize = True
        Me.lblPassprompt.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!)
        Me.lblPassprompt.Location = New System.Drawing.Point(708, 172)
        Me.lblPassprompt.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPassprompt.Name = "lblPassprompt"
        Me.lblPassprompt.Size = New System.Drawing.Size(363, 39)
        Me.lblPassprompt.TabIndex = 39
        Me.lblPassprompt.Text = "Please enter password"
        '
        'keyBack
        '
        Me.keyBack.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.keyBack.BackColor = System.Drawing.SystemColors.ControlDark
        Me.keyBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.keyBack.Location = New System.Drawing.Point(1313, 555)
        Me.keyBack.Margin = New System.Windows.Forms.Padding(4)
        Me.keyBack.Name = "keyBack"
        Me.keyBack.Size = New System.Drawing.Size(157, 69)
        Me.keyBack.TabIndex = 40
        Me.keyBack.Text = "Back"
        Me.keyBack.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        '
        'Password
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1915, 983)
        Me.Controls.Add(Me.keyBack)
        Me.Controls.Add(Me.lblPassprompt)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnEnterPassword)
        Me.Controls.Add(Me.keyM)
        Me.Controls.Add(Me.keyN)
        Me.Controls.Add(Me.keyB)
        Me.Controls.Add(Me.keyV)
        Me.Controls.Add(Me.keyC)
        Me.Controls.Add(Me.keyX)
        Me.Controls.Add(Me.keyZ)
        Me.Controls.Add(Me.keyL)
        Me.Controls.Add(Me.keyK)
        Me.Controls.Add(Me.keyJ)
        Me.Controls.Add(Me.keyH)
        Me.Controls.Add(Me.keyG)
        Me.Controls.Add(Me.keyF)
        Me.Controls.Add(Me.keyD)
        Me.Controls.Add(Me.keyS)
        Me.Controls.Add(Me.keyA)
        Me.Controls.Add(Me.keyP)
        Me.Controls.Add(Me.keyO)
        Me.Controls.Add(Me.keyI)
        Me.Controls.Add(Me.keyU)
        Me.Controls.Add(Me.keyY)
        Me.Controls.Add(Me.keyT)
        Me.Controls.Add(Me.keyR)
        Me.Controls.Add(Me.keyE)
        Me.Controls.Add(Me.keyW)
        Me.Controls.Add(Me.keyQ)
        Me.Controls.Add(Me.key0)
        Me.Controls.Add(Me.key9)
        Me.Controls.Add(Me.key8)
        Me.Controls.Add(Me.key7)
        Me.Controls.Add(Me.key6)
        Me.Controls.Add(Me.key5)
        Me.Controls.Add(Me.key4)
        Me.Controls.Add(Me.key3)
        Me.Controls.Add(Me.key2)
        Me.Controls.Add(Me.key1)
        Me.Controls.Add(Me.txtPasswordbox)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Password"
        Me.Text = "Password"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtPasswordbox As TextBox
    Friend WithEvents key1 As Button
    Friend WithEvents key2 As Button
    Friend WithEvents key3 As Button
    Friend WithEvents key4 As Button
    Friend WithEvents key5 As Button
    Friend WithEvents key6 As Button
    Friend WithEvents key7 As Button
    Friend WithEvents key8 As Button
    Friend WithEvents key9 As Button
    Friend WithEvents key0 As Button
    Friend WithEvents keyQ As Button
    Friend WithEvents keyW As Button
    Friend WithEvents keyE As Button
    Friend WithEvents keyR As Button
    Friend WithEvents keyT As Button
    Friend WithEvents keyY As Button
    Friend WithEvents keyU As Button
    Friend WithEvents keyI As Button
    Friend WithEvents keyO As Button
    Friend WithEvents keyP As Button
    Friend WithEvents keyA As Button
    Friend WithEvents keyS As Button
    Friend WithEvents keyD As Button
    Friend WithEvents keyF As Button
    Friend WithEvents keyG As Button
    Friend WithEvents keyH As Button
    Friend WithEvents keyJ As Button
    Friend WithEvents keyK As Button
    Friend WithEvents keyL As Button
    Friend WithEvents keyZ As Button
    Friend WithEvents keyX As Button
    Friend WithEvents keyC As Button
    Friend WithEvents keyV As Button
    Friend WithEvents keyB As Button
    Friend WithEvents keyN As Button
    Friend WithEvents keyM As Button
    Friend WithEvents btnEnterPassword As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents lblPassprompt As Label
    Friend WithEvents keyBack As Button
    Friend WithEvents Timer1 As Timer
End Class

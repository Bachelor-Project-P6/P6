﻿Public Class BadPassword
    Private Sub btnCloseBadPass_Click(sender As Object, e As EventArgs) Handles btnCloseBadPass.Click
        Close()
    End Sub
End Class
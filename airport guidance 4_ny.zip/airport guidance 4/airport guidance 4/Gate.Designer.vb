﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Gate
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnGate1 = New System.Windows.Forms.Button()
        Me.BtnGate2 = New System.Windows.Forms.Button()
        Me.BtnGate3 = New System.Windows.Forms.Button()
        Me.BtnGate4 = New System.Windows.Forms.Button()
        Me.BtnGate5 = New System.Windows.Forms.Button()
        Me.BtnGate6 = New System.Windows.Forms.Button()
        Me.BtnGate7 = New System.Windows.Forms.Button()
        Me.BtnGate8 = New System.Windows.Forms.Button()
        Me.BtnGate9 = New System.Windows.Forms.Button()
        Me.BtnGate10 = New System.Windows.Forms.Button()
        Me.BtnGate11 = New System.Windows.Forms.Button()
        Me.BtnBack = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'BtnGate1
        '
        Me.BtnGate1.Location = New System.Drawing.Point(115, 62)
        Me.BtnGate1.Name = "BtnGate1"
        Me.BtnGate1.Size = New System.Drawing.Size(175, 50)
        Me.BtnGate1.TabIndex = 0
        Me.BtnGate1.Text = "Gate1"
        Me.BtnGate1.UseVisualStyleBackColor = True
        '
        'BtnGate2
        '
        Me.BtnGate2.Location = New System.Drawing.Point(115, 131)
        Me.BtnGate2.Name = "BtnGate2"
        Me.BtnGate2.Size = New System.Drawing.Size(175, 50)
        Me.BtnGate2.TabIndex = 1
        Me.BtnGate2.Text = "Gate2"
        Me.BtnGate2.UseVisualStyleBackColor = True
        '
        'BtnGate3
        '
        Me.BtnGate3.Location = New System.Drawing.Point(115, 204)
        Me.BtnGate3.Name = "BtnGate3"
        Me.BtnGate3.Size = New System.Drawing.Size(175, 50)
        Me.BtnGate3.TabIndex = 2
        Me.BtnGate3.Text = "Gate3"
        Me.BtnGate3.UseVisualStyleBackColor = True
        '
        'BtnGate4
        '
        Me.BtnGate4.Location = New System.Drawing.Point(115, 276)
        Me.BtnGate4.Name = "BtnGate4"
        Me.BtnGate4.Size = New System.Drawing.Size(175, 50)
        Me.BtnGate4.TabIndex = 3
        Me.BtnGate4.Text = "Gate4"
        Me.BtnGate4.UseVisualStyleBackColor = True
        '
        'BtnGate5
        '
        Me.BtnGate5.Location = New System.Drawing.Point(309, 62)
        Me.BtnGate5.Name = "BtnGate5"
        Me.BtnGate5.Size = New System.Drawing.Size(175, 50)
        Me.BtnGate5.TabIndex = 4
        Me.BtnGate5.Text = "Gate5"
        Me.BtnGate5.UseVisualStyleBackColor = True
        '
        'BtnGate6
        '
        Me.BtnGate6.Location = New System.Drawing.Point(309, 131)
        Me.BtnGate6.Name = "BtnGate6"
        Me.BtnGate6.Size = New System.Drawing.Size(175, 50)
        Me.BtnGate6.TabIndex = 5
        Me.BtnGate6.Text = "Gate6"
        Me.BtnGate6.UseVisualStyleBackColor = True
        '
        'BtnGate7
        '
        Me.BtnGate7.Location = New System.Drawing.Point(309, 204)
        Me.BtnGate7.Name = "BtnGate7"
        Me.BtnGate7.Size = New System.Drawing.Size(175, 50)
        Me.BtnGate7.TabIndex = 6
        Me.BtnGate7.Text = "Gate7"
        Me.BtnGate7.UseVisualStyleBackColor = True
        '
        'BtnGate8
        '
        Me.BtnGate8.Location = New System.Drawing.Point(309, 276)
        Me.BtnGate8.Name = "BtnGate8"
        Me.BtnGate8.Size = New System.Drawing.Size(175, 50)
        Me.BtnGate8.TabIndex = 7
        Me.BtnGate8.Text = "Gate8"
        Me.BtnGate8.UseVisualStyleBackColor = True
        '
        'BtnGate9
        '
        Me.BtnGate9.Location = New System.Drawing.Point(504, 62)
        Me.BtnGate9.Name = "BtnGate9"
        Me.BtnGate9.Size = New System.Drawing.Size(175, 50)
        Me.BtnGate9.TabIndex = 8
        Me.BtnGate9.Text = "Gate9"
        Me.BtnGate9.UseVisualStyleBackColor = True
        '
        'BtnGate10
        '
        Me.BtnGate10.Location = New System.Drawing.Point(504, 131)
        Me.BtnGate10.Name = "BtnGate10"
        Me.BtnGate10.Size = New System.Drawing.Size(175, 50)
        Me.BtnGate10.TabIndex = 9
        Me.BtnGate10.Text = "Gate10"
        Me.BtnGate10.UseVisualStyleBackColor = True
        '
        'BtnGate11
        '
        Me.BtnGate11.Location = New System.Drawing.Point(504, 204)
        Me.BtnGate11.Name = "BtnGate11"
        Me.BtnGate11.Size = New System.Drawing.Size(175, 50)
        Me.BtnGate11.TabIndex = 10
        Me.BtnGate11.Text = "Gate11"
        Me.BtnGate11.UseVisualStyleBackColor = True
        '
        'BtnBack
        '
        Me.BtnBack.Location = New System.Drawing.Point(295, 364)
        Me.BtnBack.Name = "BtnBack"
        Me.BtnBack.Size = New System.Drawing.Size(175, 50)
        Me.BtnBack.TabIndex = 16
        Me.BtnBack.Text = "Back"
        Me.BtnBack.UseVisualStyleBackColor = True
        '
        'Gate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.BtnBack)
        Me.Controls.Add(Me.BtnGate11)
        Me.Controls.Add(Me.BtnGate10)
        Me.Controls.Add(Me.BtnGate9)
        Me.Controls.Add(Me.BtnGate8)
        Me.Controls.Add(Me.BtnGate7)
        Me.Controls.Add(Me.BtnGate6)
        Me.Controls.Add(Me.BtnGate5)
        Me.Controls.Add(Me.BtnGate4)
        Me.Controls.Add(Me.BtnGate3)
        Me.Controls.Add(Me.BtnGate2)
        Me.Controls.Add(Me.BtnGate1)
        Me.Name = "Gate"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BtnGate1 As Button
    Friend WithEvents BtnGate2 As Button
    Friend WithEvents BtnGate3 As Button
    Friend WithEvents BtnGate4 As Button
    Friend WithEvents BtnGate5 As Button
    Friend WithEvents BtnGate6 As Button
    Friend WithEvents BtnGate7 As Button
    Friend WithEvents BtnGate8 As Button
    Friend WithEvents BtnGate9 As Button
    Friend WithEvents BtnGate10 As Button
    Friend WithEvents BtnGate11 As Button
    Friend WithEvents BtnBack As Button
End Class

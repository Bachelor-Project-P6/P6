﻿namespace Airport_guidance
{
    partial class Password
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPasswordbox = new System.Windows.Forms.TextBox();
            this.key1 = new System.Windows.Forms.Button();
            this.key2 = new System.Windows.Forms.Button();
            this.key3 = new System.Windows.Forms.Button();
            this.key4 = new System.Windows.Forms.Button();
            this.key5 = new System.Windows.Forms.Button();
            this.key6 = new System.Windows.Forms.Button();
            this.key7 = new System.Windows.Forms.Button();
            this.key8 = new System.Windows.Forms.Button();
            this.key9 = new System.Windows.Forms.Button();
            this.key0 = new System.Windows.Forms.Button();
            this.keyQ = new System.Windows.Forms.Button();
            this.keyW = new System.Windows.Forms.Button();
            this.keyE = new System.Windows.Forms.Button();
            this.keyR = new System.Windows.Forms.Button();
            this.keyY = new System.Windows.Forms.Button();
            this.keyU = new System.Windows.Forms.Button();
            this.keyI = new System.Windows.Forms.Button();
            this.keyO = new System.Windows.Forms.Button();
            this.keyP = new System.Windows.Forms.Button();
            this.keyA = new System.Windows.Forms.Button();
            this.keyS = new System.Windows.Forms.Button();
            this.keyD = new System.Windows.Forms.Button();
            this.keyF = new System.Windows.Forms.Button();
            this.keyG = new System.Windows.Forms.Button();
            this.keyH = new System.Windows.Forms.Button();
            this.keyJ = new System.Windows.Forms.Button();
            this.keyL = new System.Windows.Forms.Button();
            this.keyZ = new System.Windows.Forms.Button();
            this.keyX = new System.Windows.Forms.Button();
            this.keyC = new System.Windows.Forms.Button();
            this.keyV = new System.Windows.Forms.Button();
            this.keyB = new System.Windows.Forms.Button();
            this.keyN = new System.Windows.Forms.Button();
            this.keyM = new System.Windows.Forms.Button();
            this.keyBack = new System.Windows.Forms.Button();
            this.btnEnterPassword = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.keyT = new System.Windows.Forms.Button();
            this.keyK = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F);
            this.label1.Location = new System.Drawing.Point(722, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(499, 54);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please enter password";
            // 
            // txtPasswordbox
            // 
            this.txtPasswordbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.txtPasswordbox.Location = new System.Drawing.Point(464, 244);
            this.txtPasswordbox.Multiline = true;
            this.txtPasswordbox.Name = "txtPasswordbox";
            this.txtPasswordbox.PasswordChar = '*';
            this.txtPasswordbox.Size = new System.Drawing.Size(952, 45);
            this.txtPasswordbox.TabIndex = 1;
            this.txtPasswordbox.TextChanged += new System.EventHandler(this.txtPasswordbox_TextChanged);
            // 
            // key1
            // 
            this.key1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.key1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.key1.Location = new System.Drawing.Point(372, 316);
            this.key1.Margin = new System.Windows.Forms.Padding(4);
            this.key1.Name = "key1";
            this.key1.Size = new System.Drawing.Size(107, 70);
            this.key1.TabIndex = 2;
            this.key1.Text = "1";
            this.key1.UseVisualStyleBackColor = false;
            this.key1.Click += new System.EventHandler(this.key1_Click);
            // 
            // key2
            // 
            this.key2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.key2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.key2.Location = new System.Drawing.Point(487, 316);
            this.key2.Margin = new System.Windows.Forms.Padding(4);
            this.key2.Name = "key2";
            this.key2.Size = new System.Drawing.Size(107, 70);
            this.key2.TabIndex = 3;
            this.key2.Text = "2";
            this.key2.UseVisualStyleBackColor = false;
            this.key2.Click += new System.EventHandler(this.key2_Click);
            // 
            // key3
            // 
            this.key3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.key3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.key3.Location = new System.Drawing.Point(602, 316);
            this.key3.Margin = new System.Windows.Forms.Padding(4);
            this.key3.Name = "key3";
            this.key3.Size = new System.Drawing.Size(107, 70);
            this.key3.TabIndex = 4;
            this.key3.Text = "3";
            this.key3.UseVisualStyleBackColor = false;
            this.key3.Click += new System.EventHandler(this.key3_Click);
            // 
            // key4
            // 
            this.key4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.key4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.key4.Location = new System.Drawing.Point(717, 316);
            this.key4.Margin = new System.Windows.Forms.Padding(4);
            this.key4.Name = "key4";
            this.key4.Size = new System.Drawing.Size(107, 70);
            this.key4.TabIndex = 5;
            this.key4.Text = "4";
            this.key4.UseVisualStyleBackColor = false;
            this.key4.Click += new System.EventHandler(this.key4_Click);
            // 
            // key5
            // 
            this.key5.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.key5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.key5.Location = new System.Drawing.Point(832, 316);
            this.key5.Margin = new System.Windows.Forms.Padding(4);
            this.key5.Name = "key5";
            this.key5.Size = new System.Drawing.Size(107, 70);
            this.key5.TabIndex = 6;
            this.key5.Text = "5";
            this.key5.UseVisualStyleBackColor = false;
            this.key5.Click += new System.EventHandler(this.key5_Click);
            // 
            // key6
            // 
            this.key6.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.key6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.key6.Location = new System.Drawing.Point(947, 316);
            this.key6.Margin = new System.Windows.Forms.Padding(4);
            this.key6.Name = "key6";
            this.key6.Size = new System.Drawing.Size(107, 70);
            this.key6.TabIndex = 7;
            this.key6.Text = "6";
            this.key6.UseVisualStyleBackColor = false;
            this.key6.Click += new System.EventHandler(this.key6_Click);
            // 
            // key7
            // 
            this.key7.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.key7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.key7.Location = new System.Drawing.Point(1062, 316);
            this.key7.Margin = new System.Windows.Forms.Padding(4);
            this.key7.Name = "key7";
            this.key7.Size = new System.Drawing.Size(107, 70);
            this.key7.TabIndex = 8;
            this.key7.Text = "7";
            this.key7.UseVisualStyleBackColor = false;
            this.key7.Click += new System.EventHandler(this.key7_Click);
            // 
            // key8
            // 
            this.key8.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.key8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.key8.Location = new System.Drawing.Point(1177, 316);
            this.key8.Margin = new System.Windows.Forms.Padding(4);
            this.key8.Name = "key8";
            this.key8.Size = new System.Drawing.Size(107, 70);
            this.key8.TabIndex = 9;
            this.key8.Text = "8";
            this.key8.UseVisualStyleBackColor = false;
            this.key8.Click += new System.EventHandler(this.key8_Click);
            // 
            // key9
            // 
            this.key9.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.key9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.key9.Location = new System.Drawing.Point(1292, 316);
            this.key9.Margin = new System.Windows.Forms.Padding(4);
            this.key9.Name = "key9";
            this.key9.Size = new System.Drawing.Size(107, 70);
            this.key9.TabIndex = 10;
            this.key9.Text = "9";
            this.key9.UseVisualStyleBackColor = false;
            this.key9.Click += new System.EventHandler(this.key9_Click);
            // 
            // key0
            // 
            this.key0.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.key0.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.key0.Location = new System.Drawing.Point(1407, 316);
            this.key0.Margin = new System.Windows.Forms.Padding(4);
            this.key0.Name = "key0";
            this.key0.Size = new System.Drawing.Size(107, 70);
            this.key0.TabIndex = 11;
            this.key0.Text = "0";
            this.key0.UseVisualStyleBackColor = false;
            this.key0.Click += new System.EventHandler(this.key0_Click);
            // 
            // keyQ
            // 
            this.keyQ.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyQ.Location = new System.Drawing.Point(372, 394);
            this.keyQ.Margin = new System.Windows.Forms.Padding(4);
            this.keyQ.Name = "keyQ";
            this.keyQ.Size = new System.Drawing.Size(107, 70);
            this.keyQ.TabIndex = 12;
            this.keyQ.Text = "Q";
            this.keyQ.UseVisualStyleBackColor = false;
            this.keyQ.Click += new System.EventHandler(this.keyQ_Click);
            // 
            // keyW
            // 
            this.keyW.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyW.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyW.Location = new System.Drawing.Point(487, 394);
            this.keyW.Margin = new System.Windows.Forms.Padding(4);
            this.keyW.Name = "keyW";
            this.keyW.Size = new System.Drawing.Size(107, 70);
            this.keyW.TabIndex = 13;
            this.keyW.Text = "W";
            this.keyW.UseVisualStyleBackColor = false;
            this.keyW.Click += new System.EventHandler(this.keyW_Click);
            // 
            // keyE
            // 
            this.keyE.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyE.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyE.Location = new System.Drawing.Point(602, 394);
            this.keyE.Margin = new System.Windows.Forms.Padding(4);
            this.keyE.Name = "keyE";
            this.keyE.Size = new System.Drawing.Size(107, 70);
            this.keyE.TabIndex = 14;
            this.keyE.Text = "E";
            this.keyE.UseVisualStyleBackColor = false;
            this.keyE.Click += new System.EventHandler(this.keyE_Click);
            // 
            // keyR
            // 
            this.keyR.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyR.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyR.Location = new System.Drawing.Point(717, 394);
            this.keyR.Margin = new System.Windows.Forms.Padding(4);
            this.keyR.Name = "keyR";
            this.keyR.Size = new System.Drawing.Size(107, 70);
            this.keyR.TabIndex = 15;
            this.keyR.Text = "R";
            this.keyR.UseVisualStyleBackColor = false;
            this.keyR.Click += new System.EventHandler(this.keyR_Click);
            // 
            // keyY
            // 
            this.keyY.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyY.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyY.Location = new System.Drawing.Point(947, 394);
            this.keyY.Margin = new System.Windows.Forms.Padding(4);
            this.keyY.Name = "keyY";
            this.keyY.Size = new System.Drawing.Size(107, 70);
            this.keyY.TabIndex = 17;
            this.keyY.Text = "Y";
            this.keyY.UseVisualStyleBackColor = false;
            this.keyY.Click += new System.EventHandler(this.keyY_Click);
            // 
            // keyU
            // 
            this.keyU.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyU.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyU.Location = new System.Drawing.Point(1062, 394);
            this.keyU.Margin = new System.Windows.Forms.Padding(4);
            this.keyU.Name = "keyU";
            this.keyU.Size = new System.Drawing.Size(107, 70);
            this.keyU.TabIndex = 18;
            this.keyU.Text = "U";
            this.keyU.UseVisualStyleBackColor = false;
            this.keyU.Click += new System.EventHandler(this.keyU_Click);
            // 
            // keyI
            // 
            this.keyI.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyI.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyI.Location = new System.Drawing.Point(1177, 394);
            this.keyI.Margin = new System.Windows.Forms.Padding(4);
            this.keyI.Name = "keyI";
            this.keyI.Size = new System.Drawing.Size(107, 70);
            this.keyI.TabIndex = 19;
            this.keyI.Text = "I";
            this.keyI.UseVisualStyleBackColor = false;
            this.keyI.Click += new System.EventHandler(this.keyI_Click);
            // 
            // keyO
            // 
            this.keyO.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyO.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyO.Location = new System.Drawing.Point(1292, 394);
            this.keyO.Margin = new System.Windows.Forms.Padding(4);
            this.keyO.Name = "keyO";
            this.keyO.Size = new System.Drawing.Size(107, 70);
            this.keyO.TabIndex = 20;
            this.keyO.Text = "O";
            this.keyO.UseVisualStyleBackColor = false;
            this.keyO.Click += new System.EventHandler(this.keyO_Click);
            // 
            // keyP
            // 
            this.keyP.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyP.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyP.Location = new System.Drawing.Point(1407, 394);
            this.keyP.Margin = new System.Windows.Forms.Padding(4);
            this.keyP.Name = "keyP";
            this.keyP.Size = new System.Drawing.Size(107, 70);
            this.keyP.TabIndex = 21;
            this.keyP.Text = "P";
            this.keyP.UseVisualStyleBackColor = false;
            this.keyP.Click += new System.EventHandler(this.keyP_Click);
            // 
            // keyA
            // 
            this.keyA.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyA.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyA.Location = new System.Drawing.Point(424, 472);
            this.keyA.Margin = new System.Windows.Forms.Padding(4);
            this.keyA.Name = "keyA";
            this.keyA.Size = new System.Drawing.Size(107, 70);
            this.keyA.TabIndex = 22;
            this.keyA.Text = "A";
            this.keyA.UseVisualStyleBackColor = false;
            this.keyA.Click += new System.EventHandler(this.keyA_Click);
            // 
            // keyS
            // 
            this.keyS.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyS.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyS.Location = new System.Drawing.Point(539, 472);
            this.keyS.Margin = new System.Windows.Forms.Padding(4);
            this.keyS.Name = "keyS";
            this.keyS.Size = new System.Drawing.Size(107, 70);
            this.keyS.TabIndex = 23;
            this.keyS.Text = "S";
            this.keyS.UseVisualStyleBackColor = false;
            this.keyS.Click += new System.EventHandler(this.keyS_Click);
            // 
            // keyD
            // 
            this.keyD.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyD.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyD.Location = new System.Drawing.Point(654, 472);
            this.keyD.Margin = new System.Windows.Forms.Padding(4);
            this.keyD.Name = "keyD";
            this.keyD.Size = new System.Drawing.Size(107, 70);
            this.keyD.TabIndex = 24;
            this.keyD.Text = "D";
            this.keyD.UseVisualStyleBackColor = false;
            this.keyD.Click += new System.EventHandler(this.keyD_Click);
            // 
            // keyF
            // 
            this.keyF.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyF.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyF.Location = new System.Drawing.Point(769, 472);
            this.keyF.Margin = new System.Windows.Forms.Padding(4);
            this.keyF.Name = "keyF";
            this.keyF.Size = new System.Drawing.Size(107, 70);
            this.keyF.TabIndex = 25;
            this.keyF.Text = "F";
            this.keyF.UseVisualStyleBackColor = false;
            this.keyF.Click += new System.EventHandler(this.keyF_Click);
            // 
            // keyG
            // 
            this.keyG.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyG.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyG.Location = new System.Drawing.Point(884, 472);
            this.keyG.Margin = new System.Windows.Forms.Padding(4);
            this.keyG.Name = "keyG";
            this.keyG.Size = new System.Drawing.Size(107, 70);
            this.keyG.TabIndex = 26;
            this.keyG.Text = "G";
            this.keyG.UseVisualStyleBackColor = false;
            this.keyG.Click += new System.EventHandler(this.keyG_Click);
            // 
            // keyH
            // 
            this.keyH.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyH.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyH.Location = new System.Drawing.Point(999, 472);
            this.keyH.Margin = new System.Windows.Forms.Padding(4);
            this.keyH.Name = "keyH";
            this.keyH.Size = new System.Drawing.Size(107, 70);
            this.keyH.TabIndex = 27;
            this.keyH.Text = "H";
            this.keyH.UseVisualStyleBackColor = false;
            this.keyH.Click += new System.EventHandler(this.keyH_Click);
            // 
            // keyJ
            // 
            this.keyJ.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyJ.Location = new System.Drawing.Point(1114, 472);
            this.keyJ.Margin = new System.Windows.Forms.Padding(4);
            this.keyJ.Name = "keyJ";
            this.keyJ.Size = new System.Drawing.Size(107, 70);
            this.keyJ.TabIndex = 28;
            this.keyJ.Text = "J";
            this.keyJ.UseVisualStyleBackColor = false;
            this.keyJ.Click += new System.EventHandler(this.keyJ_Click);
            // 
            // keyL
            // 
            this.keyL.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyL.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyL.Location = new System.Drawing.Point(1344, 472);
            this.keyL.Margin = new System.Windows.Forms.Padding(4);
            this.keyL.Name = "keyL";
            this.keyL.Size = new System.Drawing.Size(107, 70);
            this.keyL.TabIndex = 30;
            this.keyL.Text = "L";
            this.keyL.UseVisualStyleBackColor = false;
            this.keyL.Click += new System.EventHandler(this.keyL_Click);
            // 
            // keyZ
            // 
            this.keyZ.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyZ.Location = new System.Drawing.Point(539, 550);
            this.keyZ.Margin = new System.Windows.Forms.Padding(4);
            this.keyZ.Name = "keyZ";
            this.keyZ.Size = new System.Drawing.Size(107, 70);
            this.keyZ.TabIndex = 31;
            this.keyZ.Text = "Z";
            this.keyZ.UseVisualStyleBackColor = false;
            this.keyZ.Click += new System.EventHandler(this.keyZ_Click);
            // 
            // keyX
            // 
            this.keyX.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyX.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyX.Location = new System.Drawing.Point(654, 550);
            this.keyX.Margin = new System.Windows.Forms.Padding(4);
            this.keyX.Name = "keyX";
            this.keyX.Size = new System.Drawing.Size(107, 70);
            this.keyX.TabIndex = 32;
            this.keyX.Text = "X";
            this.keyX.UseVisualStyleBackColor = false;
            this.keyX.Click += new System.EventHandler(this.keyX_Click);
            // 
            // keyC
            // 
            this.keyC.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyC.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyC.Location = new System.Drawing.Point(769, 550);
            this.keyC.Margin = new System.Windows.Forms.Padding(4);
            this.keyC.Name = "keyC";
            this.keyC.Size = new System.Drawing.Size(107, 70);
            this.keyC.TabIndex = 33;
            this.keyC.Text = "C";
            this.keyC.UseVisualStyleBackColor = false;
            this.keyC.Click += new System.EventHandler(this.keyC_Click);
            // 
            // keyV
            // 
            this.keyV.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyV.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyV.Location = new System.Drawing.Point(884, 550);
            this.keyV.Margin = new System.Windows.Forms.Padding(4);
            this.keyV.Name = "keyV";
            this.keyV.Size = new System.Drawing.Size(107, 70);
            this.keyV.TabIndex = 34;
            this.keyV.Text = "V";
            this.keyV.UseVisualStyleBackColor = false;
            this.keyV.Click += new System.EventHandler(this.keyV_Click);
            // 
            // keyB
            // 
            this.keyB.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyB.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyB.Location = new System.Drawing.Point(999, 550);
            this.keyB.Margin = new System.Windows.Forms.Padding(4);
            this.keyB.Name = "keyB";
            this.keyB.Size = new System.Drawing.Size(107, 70);
            this.keyB.TabIndex = 35;
            this.keyB.Text = "B";
            this.keyB.UseVisualStyleBackColor = false;
            this.keyB.Click += new System.EventHandler(this.keyB_Click);
            // 
            // keyN
            // 
            this.keyN.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyN.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyN.Location = new System.Drawing.Point(1114, 550);
            this.keyN.Margin = new System.Windows.Forms.Padding(4);
            this.keyN.Name = "keyN";
            this.keyN.Size = new System.Drawing.Size(107, 70);
            this.keyN.TabIndex = 36;
            this.keyN.Text = "N";
            this.keyN.UseVisualStyleBackColor = false;
            this.keyN.Click += new System.EventHandler(this.keyN_Click);
            // 
            // keyM
            // 
            this.keyM.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyM.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyM.Location = new System.Drawing.Point(1229, 550);
            this.keyM.Margin = new System.Windows.Forms.Padding(4);
            this.keyM.Name = "keyM";
            this.keyM.Size = new System.Drawing.Size(107, 70);
            this.keyM.TabIndex = 37;
            this.keyM.Text = "M";
            this.keyM.UseVisualStyleBackColor = false;
            this.keyM.Click += new System.EventHandler(this.keyM_Click);
            // 
            // keyBack
            // 
            this.keyBack.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyBack.Location = new System.Drawing.Point(1344, 550);
            this.keyBack.Margin = new System.Windows.Forms.Padding(4);
            this.keyBack.Name = "keyBack";
            this.keyBack.Size = new System.Drawing.Size(170, 70);
            this.keyBack.TabIndex = 38;
            this.keyBack.Text = "Back";
            this.keyBack.UseVisualStyleBackColor = false;
            this.keyBack.Click += new System.EventHandler(this.keyBack_Click);
            // 
            // btnEnterPassword
            // 
            this.btnEnterPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnEnterPassword.Location = new System.Drawing.Point(424, 697);
            this.btnEnterPassword.Name = "btnEnterPassword";
            this.btnEnterPassword.Size = new System.Drawing.Size(443, 143);
            this.btnEnterPassword.TabIndex = 40;
            this.btnEnterPassword.Text = "ENTER";
            this.btnEnterPassword.UseVisualStyleBackColor = true;
            this.btnEnterPassword.Click += new System.EventHandler(this.btnEnterPassword_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.btnCancel.Location = new System.Drawing.Point(1112, 697);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(443, 143);
            this.btnCancel.TabIndex = 41;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // keyT
            // 
            this.keyT.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyT.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyT.Location = new System.Drawing.Point(832, 394);
            this.keyT.Margin = new System.Windows.Forms.Padding(4);
            this.keyT.Name = "keyT";
            this.keyT.Size = new System.Drawing.Size(107, 70);
            this.keyT.TabIndex = 44;
            this.keyT.Text = "T";
            this.keyT.UseVisualStyleBackColor = false;
            this.keyT.Click += new System.EventHandler(this.keyT_Click);
            // 
            // keyK
            // 
            this.keyK.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.keyK.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.keyK.Location = new System.Drawing.Point(1229, 472);
            this.keyK.Margin = new System.Windows.Forms.Padding(4);
            this.keyK.Name = "keyK";
            this.keyK.Size = new System.Drawing.Size(107, 70);
            this.keyK.TabIndex = 45;
            this.keyK.Text = "K";
            this.keyK.UseVisualStyleBackColor = false;
            this.keyK.Click += new System.EventHandler(this.keyK_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Password
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1915, 983);
            this.Controls.Add(this.keyK);
            this.Controls.Add(this.keyT);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnEnterPassword);
            this.Controls.Add(this.keyBack);
            this.Controls.Add(this.keyM);
            this.Controls.Add(this.keyN);
            this.Controls.Add(this.keyB);
            this.Controls.Add(this.keyV);
            this.Controls.Add(this.keyC);
            this.Controls.Add(this.keyX);
            this.Controls.Add(this.keyZ);
            this.Controls.Add(this.keyL);
            this.Controls.Add(this.keyJ);
            this.Controls.Add(this.keyH);
            this.Controls.Add(this.keyG);
            this.Controls.Add(this.keyF);
            this.Controls.Add(this.keyD);
            this.Controls.Add(this.keyS);
            this.Controls.Add(this.keyA);
            this.Controls.Add(this.keyP);
            this.Controls.Add(this.keyO);
            this.Controls.Add(this.keyI);
            this.Controls.Add(this.keyU);
            this.Controls.Add(this.keyY);
            this.Controls.Add(this.keyR);
            this.Controls.Add(this.keyE);
            this.Controls.Add(this.keyW);
            this.Controls.Add(this.keyQ);
            this.Controls.Add(this.key0);
            this.Controls.Add(this.key9);
            this.Controls.Add(this.key8);
            this.Controls.Add(this.key7);
            this.Controls.Add(this.key6);
            this.Controls.Add(this.key5);
            this.Controls.Add(this.key4);
            this.Controls.Add(this.key3);
            this.Controls.Add(this.key2);
            this.Controls.Add(this.key1);
            this.Controls.Add(this.txtPasswordbox);
            this.Controls.Add(this.label1);
            this.Name = "Password";
            this.Text = "Password";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Password_Load);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Password_MouseMove);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPasswordbox;
        private System.Windows.Forms.Button key1;
        private System.Windows.Forms.Button key2;
        private System.Windows.Forms.Button key3;
        private System.Windows.Forms.Button key4;
        private System.Windows.Forms.Button key5;
        private System.Windows.Forms.Button key6;
        private System.Windows.Forms.Button key7;
        private System.Windows.Forms.Button key8;
        private System.Windows.Forms.Button key9;
        private System.Windows.Forms.Button key0;
        private System.Windows.Forms.Button keyQ;
        private System.Windows.Forms.Button keyW;
        private System.Windows.Forms.Button keyE;
        private System.Windows.Forms.Button keyR;
        private System.Windows.Forms.Button keyY;
        private System.Windows.Forms.Button keyU;
        private System.Windows.Forms.Button keyI;
        private System.Windows.Forms.Button keyO;
        private System.Windows.Forms.Button keyP;
        private System.Windows.Forms.Button keyA;
        private System.Windows.Forms.Button keyS;
        private System.Windows.Forms.Button keyD;
        private System.Windows.Forms.Button keyF;
        private System.Windows.Forms.Button keyG;
        private System.Windows.Forms.Button keyH;
        private System.Windows.Forms.Button keyJ;
        private System.Windows.Forms.Button keyL;
        private System.Windows.Forms.Button keyZ;
        private System.Windows.Forms.Button keyX;
        private System.Windows.Forms.Button keyC;
        private System.Windows.Forms.Button keyV;
        private System.Windows.Forms.Button keyB;
        private System.Windows.Forms.Button keyN;
        private System.Windows.Forms.Button keyM;
        private System.Windows.Forms.Button keyBack;
        private System.Windows.Forms.Button btnEnterPassword;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button keyT;
        private System.Windows.Forms.Button keyK;
        private System.Windows.Forms.Timer timer1;
    }
}
﻿namespace Airport_guidance
{
    partial class Gate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGate1 = new System.Windows.Forms.Button();
            this.btnGate2 = new System.Windows.Forms.Button();
            this.btnGate3 = new System.Windows.Forms.Button();
            this.btnGate4 = new System.Windows.Forms.Button();
            this.btnGate5 = new System.Windows.Forms.Button();
            this.btnGate6 = new System.Windows.Forms.Button();
            this.btnGate7 = new System.Windows.Forms.Button();
            this.btnGate8 = new System.Windows.Forms.Button();
            this.btnGate9 = new System.Windows.Forms.Button();
            this.btnGate10 = new System.Windows.Forms.Button();
            this.btnGate11 = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGate1
            // 
            this.btnGate1.Location = new System.Drawing.Point(151, 94);
            this.btnGate1.Name = "btnGate1";
            this.btnGate1.Size = new System.Drawing.Size(123, 40);
            this.btnGate1.TabIndex = 0;
            this.btnGate1.Text = "Gate1";
            this.btnGate1.UseVisualStyleBackColor = true;
            this.btnGate1.Click += new System.EventHandler(this.btnGate1_Click);
            // 
            // btnGate2
            // 
            this.btnGate2.Location = new System.Drawing.Point(151, 156);
            this.btnGate2.Name = "btnGate2";
            this.btnGate2.Size = new System.Drawing.Size(123, 40);
            this.btnGate2.TabIndex = 1;
            this.btnGate2.Text = "Gate2";
            this.btnGate2.UseVisualStyleBackColor = true;
            this.btnGate2.Click += new System.EventHandler(this.btnGate2_Click);
            // 
            // btnGate3
            // 
            this.btnGate3.Location = new System.Drawing.Point(151, 214);
            this.btnGate3.Name = "btnGate3";
            this.btnGate3.Size = new System.Drawing.Size(123, 40);
            this.btnGate3.TabIndex = 2;
            this.btnGate3.Text = "Gate3";
            this.btnGate3.UseVisualStyleBackColor = true;
            this.btnGate3.Click += new System.EventHandler(this.btnGate3_Click);
            // 
            // btnGate4
            // 
            this.btnGate4.Location = new System.Drawing.Point(151, 272);
            this.btnGate4.Name = "btnGate4";
            this.btnGate4.Size = new System.Drawing.Size(123, 40);
            this.btnGate4.TabIndex = 3;
            this.btnGate4.Text = "Gate4";
            this.btnGate4.UseVisualStyleBackColor = true;
            this.btnGate4.Click += new System.EventHandler(this.btnGate4_Click);
            // 
            // btnGate5
            // 
            this.btnGate5.Location = new System.Drawing.Point(333, 94);
            this.btnGate5.Name = "btnGate5";
            this.btnGate5.Size = new System.Drawing.Size(123, 40);
            this.btnGate5.TabIndex = 4;
            this.btnGate5.Text = "Gate5";
            this.btnGate5.UseVisualStyleBackColor = true;
            this.btnGate5.Click += new System.EventHandler(this.btnGate5_Click);
            // 
            // btnGate6
            // 
            this.btnGate6.Location = new System.Drawing.Point(333, 156);
            this.btnGate6.Name = "btnGate6";
            this.btnGate6.Size = new System.Drawing.Size(123, 40);
            this.btnGate6.TabIndex = 5;
            this.btnGate6.Text = "Gate6";
            this.btnGate6.UseVisualStyleBackColor = true;
            this.btnGate6.Click += new System.EventHandler(this.btnGate6_Click);
            // 
            // btnGate7
            // 
            this.btnGate7.Location = new System.Drawing.Point(333, 214);
            this.btnGate7.Name = "btnGate7";
            this.btnGate7.Size = new System.Drawing.Size(123, 40);
            this.btnGate7.TabIndex = 6;
            this.btnGate7.Text = "Gate7";
            this.btnGate7.UseVisualStyleBackColor = true;
            this.btnGate7.Click += new System.EventHandler(this.btnGate7_Click);
            // 
            // btnGate8
            // 
            this.btnGate8.Location = new System.Drawing.Point(333, 272);
            this.btnGate8.Name = "btnGate8";
            this.btnGate8.Size = new System.Drawing.Size(123, 40);
            this.btnGate8.TabIndex = 7;
            this.btnGate8.Text = "Gate8";
            this.btnGate8.UseVisualStyleBackColor = true;
            this.btnGate8.Click += new System.EventHandler(this.btnGate8_Click);
            // 
            // btnGate9
            // 
            this.btnGate9.Location = new System.Drawing.Point(534, 94);
            this.btnGate9.Name = "btnGate9";
            this.btnGate9.Size = new System.Drawing.Size(123, 40);
            this.btnGate9.TabIndex = 8;
            this.btnGate9.Text = "Gate9";
            this.btnGate9.UseVisualStyleBackColor = true;
            this.btnGate9.Click += new System.EventHandler(this.btnGate9_Click);
            // 
            // btnGate10
            // 
            this.btnGate10.Location = new System.Drawing.Point(534, 156);
            this.btnGate10.Name = "btnGate10";
            this.btnGate10.Size = new System.Drawing.Size(123, 40);
            this.btnGate10.TabIndex = 9;
            this.btnGate10.Text = "Gate10";
            this.btnGate10.UseVisualStyleBackColor = true;
            this.btnGate10.Click += new System.EventHandler(this.btnGate10_Click);
            // 
            // btnGate11
            // 
            this.btnGate11.Location = new System.Drawing.Point(534, 214);
            this.btnGate11.Name = "btnGate11";
            this.btnGate11.Size = new System.Drawing.Size(123, 40);
            this.btnGate11.TabIndex = 10;
            this.btnGate11.Text = "Gate11";
            this.btnGate11.UseVisualStyleBackColor = true;
            this.btnGate11.Click += new System.EventHandler(this.btnGate11_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(346, 352);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(88, 40);
            this.btnCancel.TabIndex = 16;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // Gate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnGate11);
            this.Controls.Add(this.btnGate10);
            this.Controls.Add(this.btnGate9);
            this.Controls.Add(this.btnGate8);
            this.Controls.Add(this.btnGate7);
            this.Controls.Add(this.btnGate6);
            this.Controls.Add(this.btnGate5);
            this.Controls.Add(this.btnGate4);
            this.Controls.Add(this.btnGate3);
            this.Controls.Add(this.btnGate2);
            this.Controls.Add(this.btnGate1);
            this.Name = "Gate";
            this.Text = "Gate";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGate1;
        private System.Windows.Forms.Button btnGate2;
        private System.Windows.Forms.Button btnGate3;
        private System.Windows.Forms.Button btnGate4;
        private System.Windows.Forms.Button btnGate5;
        private System.Windows.Forms.Button btnGate6;
        private System.Windows.Forms.Button btnGate7;
        private System.Windows.Forms.Button btnGate8;
        private System.Windows.Forms.Button btnGate9;
        private System.Windows.Forms.Button btnGate10;
        private System.Windows.Forms.Button btnGate11;
        private System.Windows.Forms.Button btnCancel;
    }
}